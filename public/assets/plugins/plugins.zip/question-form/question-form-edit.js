$(document).ready(function() {
    // Initialize Quill for Question Text
    const quill = new Quill('#questionTextEditor', {
        theme: 'snow',
        modules: {
            toolbar: [
                ['bold', 'italic', 'underline', 'strike'], // toggled buttons
                ['formula'],
                [{ 'direction': 'rtl' }], // text direction
                [{ 'align': [] }],
                ['clean']
            ]
        },
        placeholder: 'Enter the question text here...'
    });

    quill.on('text-change', function() {
        $('#questionText').val(JSON.stringify(quill.getContents())); // Store delta as JSON
    });

    // Initialize Quill for Hint
    const hintQuill = new Quill('#hintEditor', {
        theme: 'snow',
        modules: {
            toolbar: [
                ['bold', 'italic', 'underline', 'strike'], // toggled buttons
                ['formula'],
                [{ 'direction': 'rtl' }], // text direction
                [{ 'align': [] }],
                ['clean']
            ]
        },
        placeholder: 'Enter a hint to help the user...'
    });

    hintQuill.on('text-change', function() {
        $('#hint').val(JSON.stringify(hintQuill.getContents())); // Store delta as JSON
    });

    let correctAnswerQuill;

    // Load existing data into Quill editors
    const questionText = JSON.parse($('#questionText').val() || '{}');
    if (quill && questionText) {
        quill.setContents(questionText);
    }

    const hintText = JSON.parse($('#hint').val() || '{}');
    if (hintQuill && hintText) {
        hintQuill.setContents(hintText);
    }

    // Function to update hiddenChoices field
    function updateHiddenChoices() {
        const choices = [];
        $('.choiceEditor').each(function() {
            const choiceQuill = Quill.find(this);
            choices.push(choiceQuill.getContents()); // Store delta
        });
        $('#hiddenChoices').val(JSON.stringify(choices)); // Update hiddenChoices with delta
    }

    // Function to initialize choice editors
    function initializeChoiceEditors() {
        $('.choiceEditor').each(function(index) {
            if (!$(this).data('quill-initialized')) {
                const choiceQuill = new Quill(this, {
                    theme: 'snow',
                    modules: {
                        toolbar: [
                            ['bold', 'italic', 'underline', 'strike'], // toggled buttons
                            ['formula'],
                            [{ 'direction': 'rtl' }], // text direction
                            [{ 'align': [] }],
                            ['clean']
                        ]
                    },
                    placeholder: 'Enter choice text here...'
                });

                // Load existing choice content
                const choices = JSON.parse($('#hiddenChoices').val() || '[]');
                if (choices[index]) {
                    choiceQuill.setContents(choices[index]);
                }

                choiceQuill.on('text-change', function() {
                    $(this).closest('.border').find('.choiceInput').val(JSON.stringify(choiceQuill.getContents()));
                    updateHiddenChoices();
                });

                $(this).data('quill-initialized', true);
            }
        });
    }

    // Function to manage choices
    function manageChoices() {
        let choiceCount = 2;

        $('#addChoice').click(function() {
            if (choiceCount < 6) {
                choiceCount++;
                const newChoice = `
                    <div class="mb-2 border p-3 rounded">
                        <div class="choiceEditor question-editor" style="height: 100px;" data-placeholder="Enter choice text here..."></div>
                        <input id="choice${choiceCount}" type="hidden" name="choice${choiceCount}" class="choiceInput" required>
                        <div class="mt-2 mx-4">
                            <input type="radio" name="correctAnswer" value="${choiceCount}" class="form-check-input" required><span class="mx-3">Correct Answer</span>
                        </div>
                    </div>
                `;
                $('#choicesContainer').append(newChoice);
                initializeChoiceEditors();
                updateHiddenChoices();
            }
        });

        $('#removeChoice').click(function() {
            if (choiceCount > 2) {
                $('#choicesContainer').children().last().remove();
                choiceCount--;
                updateHiddenChoices();
            }
        });
    }

    // Function to load answer section based on question type
    function loadAnswerSection(questionType) {
        let answerHtml = '';

        if (questionType === '2') {
            answerHtml = `
                <label class="card-title mb-1">Answer</label>
                <select id="trueFalseSelector" class="form-control" name="correctAnswer" required>
                    <option value="" selected disabled>Select an answer</option>
                    <option value="1">True</option>
                    <option value="2">False</option>
                </select>
            `;
        } else if (questionType === '1') {
            answerHtml = `
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <label class="card-title mb-1">Choices</label>
                    <div>
                        <button type="button" class="btn btn-outline-success btn-sm" id="addChoice">Add Choice</button>
                        <button type="button" class="btn btn-outline-danger btn-sm" id="removeChoice">Remove Choice</button>
                    </div>
                </div>
                <div id="choicesContainer">
                    <div class="mb-2 border p-3 rounded">
                        <div class="choiceEditor question-editor" style="height: 100px;" data-placeholder="Enter choice text here..."></div>
                        <input id="choice1" type="hidden" name="choice1" class="choiceInput" required>
                        <div class="mt-2 mx-4">
                            <input type="radio" name="correctAnswer" value="1" class="form-check-input" required><span class="mx-3">Correct Answer</span>
                        </div>
                    </div>
                    <div class="mb-2 border p-3 rounded">
                        <div class="choiceEditor question-editor" style="height: 100px;" data-placeholder="Enter choice text here..."></div>
                        <input id="choice2" type="hidden" name="choice2" class="choiceInput" required>
                        <div class="mt-2 mx-4">
                            <input type="radio" name="correctAnswer" value="2" class="form-check-input" required><span class="mx-3">Correct Answer</span>
                        </div>
                    </div>
                </div>
            `;
        } else {
            answerHtml = `
                <label class="card-title mb-1">Correct Answer</label>
                <div class="question-editor" id="correctAnswerEditor" style="height: 100px;" data-placeholder="Enter the correct answer here..."></div>
                <input type="hidden" name="correctAnswer" id="correctAnswer" required>
            `;
        }

        $('#answerSection').html(answerHtml);

        if (questionType === '1') {
            initializeChoiceEditors();
            manageChoices();

            // Load existing choices and correct answer
            const choices = JSON.parse($('#hiddenChoices').val() || '[]');
            choices.forEach((choice, index) => {
                const choiceQuill = Quill.find($('.choiceEditor').get(index));
                if (choiceQuill && choice) {
                    choiceQuill.setContents(choice);
                }
            });

            const correctAnswer = $('#hiddenCorrectAnswer').val();
            if (correctAnswer) {
                $(`input[name="correctAnswer"][value="${correctAnswer}"]`).prop('checked', true);
            }
        } else if (questionType === '2') {
            // Load existing true/false answer
            const correctAnswer = $('#hiddenCorrectAnswer').val();
            if (correctAnswer) {
                $('#trueFalseSelector').val(correctAnswer);
            }
        } else if (questionType > 2) {
            // Load correct answer from choices for questionType > 2
            correctAnswerQuill = new Quill('#correctAnswerEditor', {
                theme: 'snow',
                modules: {
                    toolbar: [
                        ['bold', 'italic', 'underline', 'strike'], // toggled buttons
                        ['formula'],
                        [{ 'direction': 'rtl' }], // text direction
                        [{ 'align': [] }],
                        ['clean']
                    ]
                },
                placeholder: 'Enter the correct answer here...'
            });

            const choices = JSON.parse($('#hiddenChoices').val() || '[{}]');
            if (correctAnswerQuill && choices[0]) {
                correctAnswerQuill.setContents(choices[0]);
            }

            correctAnswerQuill.on('text-change', function() {
                $('#correctAnswer').val(JSON.stringify(correctAnswerQuill.getContents()));
            });
        }
    }

    // Load answer section based on current question type
    const currentQuestionType = $('#questionType').val();
    if (currentQuestionType) {
        loadAnswerSection(currentQuestionType);
    }

    // Handle question type change
    $('#questionType').change(function() {
        const questionType = $(this).val();
        loadAnswerSection(questionType);
    });

    // Form Submission Validation
    $('form').on('submit', function(event) {
        let isValid = true;

        // Check Question Text
        const questionText = quill.getText().trim();
        if (questionText === '') {
            alert('Please enter the question text.');
            isValid = false;
        }

        // Check Choices (if multiple choice)
        if ($('#questionType').val() === '1') {
            $('.choiceEditor').each(function() {
                const choiceQuill = Quill.find(this);
                if (choiceQuill.getText().trim() === '') {
                    alert('Please fill in all choices.');
                    isValid = false;
                    return false; // Exit the loop
                }
            });

            // Check if a correct answer is selected
            if ($('input[name="correctAnswer"]:checked').length === 0) {
                alert('Please select the correct answer.');
                isValid = false;
            }
        } else if ($('#questionType').val() === '2') {
            // Check trueFalse answer
            if ($('#trueFalseSelector').val() === null) {
                alert('Please select a correct choice.');
                isValid = false;
            }
        } else if ($('#questionType').val() > 2) {
            // Check Correct answer for questionType > 2
            const CorrectAnswerText = correctAnswerQuill.getText().trim();
            if (CorrectAnswerText === '') {
                alert('Please enter a correct answer.');
                isValid = false;
            }
        }

        // Prevent form submission if validation fails
        if (!isValid) {
            event.preventDefault();
        } else {
            // Prepare data for submission
            if ($('#questionType').val() === '1') {
                updateHiddenChoices();
                const correctAnswer = $('input[name="correctAnswer"]:checked').val();
                $('#hiddenCorrectAnswer').val(correctAnswer);
            } else if ($('#questionType').val() === '2') {
                const correctAnswer = $('#trueFalseSelector').val();
                $('#hiddenCorrectAnswer').val(correctAnswer);
            } else if ($('#questionType').val() > 2) {
                // Store correct answer in choices for questionType > 2
                const correctAnswer = correctAnswerQuill.getContents(); // Get the delta directly
                $('#hiddenChoices').val(JSON.stringify([correctAnswer])); // Store as an array of one object
            }

            // Continue with form submission
            return true;
        }
    });
});

// Image validation for question and hint photos
document.getElementById("questionPhoto").addEventListener("change", function(event) {
    const questionPhoto = event.target.files[0];

    if (questionPhoto) {
        const allowedTypes = ["image/jpeg", "image/png"];
        const maxSize = 1 * 1024 * 1024;

        if (!allowedTypes.includes(questionPhoto.type)) {
            alert('Images must be in jpg, png format');
            event.target.value = "";
        } else if (questionPhoto.size > maxSize) {
            alert('Image size must be less than 1MB');
            event.target.value = "";
        }
    }
});

document.getElementById("hintPhoto").addEventListener("change", function(event) {
    const hintPhoto = event.target.files[0];

    if (hintPhoto) {
        const allowedTypes = ["image/jpeg", "image/png"];
        const maxSize = 1 * 1024 * 1024;

        if (!allowedTypes.includes(hintPhoto.type)) {
            alert('Images must be in jpg, png format');
            event.target.value = "";
        } else if (hintPhoto.size > maxSize) {
            alert('Image size must be less than 1MB');
            event.target.value = "";
        }
    }
});
